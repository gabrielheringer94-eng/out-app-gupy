// Service Worker — versão limpa, sem cache
self.addEventListener('install', e => {
  self.skipWaiting();
});
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.map(key => caches.delete(key)))
    ).then(() => self.clients.claim())
  );
});
// Sem cache — sempre busca da rede
self.addEventListener('fetch', e => {
  e.respondWith(fetch(e.request));
});
